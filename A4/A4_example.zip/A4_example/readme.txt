Usage: 
Press the up arrow key to select a child part.
Press the down arrow key to select the parent part.
Press the left and right arrow keys to cycle the neighbor parts. 
Press A and D keys to rotate the current selected part. 