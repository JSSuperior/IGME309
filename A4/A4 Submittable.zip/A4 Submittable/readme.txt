Usage:
Press A and D keys to rotate the selected part
Press W and S to navigate through list of body parts