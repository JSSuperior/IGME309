This is an executable of A02 which allows you to create polyons using keyboard and mouse. 

Usage: 
- Right click on the mouse and choose a color for the polygon you're currently creating. 
- Click on the screen with the left mouse button to add a vertex to the polygon. 
- Press 'Enter' key on the keyboard to finish the creation of the current polygon. 
- Right click on the mouse and choose 'clear' to remove all polygons.
- Right click on the mouse and choose 'quit' to quit the program. 