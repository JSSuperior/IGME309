Theo Ruefli 309 Assignment 02 readMe

Usage:
- Right click the canvas and select 'Color' to change the color for the current and future polygons you create.
- Left click the canvas to add a vertex to your current polygon.
- Press the 'a' key on the keyboard to finish your current polygon.
- Right click the canvas and select 'Clear' to clear the canvas.
- Right click the canvas and select 'Quit' to exit the program.